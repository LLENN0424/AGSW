#include <DxLib.h>
#include <string>
#include "Vector2.h"
#include "InputManager.h"
#include "application.h"
#include "AsoUtility.h"
#include "SceneGame.h"
#include "stage.h"
#include "Efect.h"

Efect::Efect(void)
{
    sceneGame_ = nullptr;
    stage_ = nullptr;
    pos_ = { 0,0 };
    isEfect_ = true;
}

Efect::~Efect()
{
}

bool Efect::Init(SceneGame* parent)
{
    sceneGame_ = parent;

    //�摜�̓ǂݍ���
    efeimg_ = LoadGraph("bmp/bmp/kirakira_01_yellow.png");
    if (efeimg_ == -1)
    {
        return false;
    }

    pos_ = { 100,100 };

    return true;
}

void Efect::Update(void)
{

}

void Efect::Draw(void)
{
    //�J�������W�̎擾
    Vector2 cameraPos = sceneGame_->GetCameraPos();

    DrawGraph(-cameraPos.x + pos_.x,-cameraPos.y + pos_.y, efeimg_, true);
}

bool Efect::Release(void)
{
    return false;
}

void Efect::SetPos(Vector2 pos)
{
    pos_ = pos;
}

Vector2 Efect::GetPos(void)
{
    return pos_;
}
