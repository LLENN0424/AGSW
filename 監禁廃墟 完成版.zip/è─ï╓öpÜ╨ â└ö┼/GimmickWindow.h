//#pragma once
class SceneManager;
class SceneGame;
class Player;
class Stage;
class Item;

class GimmickWindow
{
public:
    static constexpr int WINDOW_SIZE_X = 100;
    static constexpr int WINDOW_SIZE_Y = 50;

    //�R���X�g���N�^
    GimmickWindow(Item* itam, Stage* stage, Player* player);

    //�f�X�g���N�^
    ~GimmickWindow();

    bool Init(SceneGame* parent, Item* item, Stage* stage, Player* player);         //����������
    void Update(void);                    //�X�V����
    void Draw(void);                    //�`�揈��
    bool Release(void);                    //�������

    Vector2 World2MapPos(Vector2 worldPos);

private:
    SceneManager* sceneManager_;
    SceneGame* sceneGame_;
    Player* player_;
    Stage* stage_;
    Item* item_;

    bool isWindow_;

    VECTOR sPos_;
    VECTOR ePos_;
};

