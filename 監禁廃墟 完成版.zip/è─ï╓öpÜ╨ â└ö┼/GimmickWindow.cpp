#include "SceneManager.h"
#include "InputManager.h"
#include "application.h"
#include "AsoUtility.h"
#include "SceneGame.h"
#include "stage.h"
#include "player.h"
#include "item.h"
#include "GimmickWindow.h"

GimmickWindow::GimmickWindow(Item* item, Stage* stage, Player* player)
{
    isWindow_ = false;
    item_ = item;
    stage_ = stage;
    player_ = player;
}

GimmickWindow::~GimmickWindow()
{
}

bool GimmickWindow::Init(SceneGame* parent, Item* item, Stage* stage, Player* player)
{
    player_ = player;
    stage_ = stage;
    item_ = item;
    sceneGame_ = parent;
    isWindow_ = false;

    return true;
}

void GimmickWindow::Update(void)
{

    Vector2 mapPos;
    mapPos = World2MapPos(player_->GetPos());
    Vector2 pos = sceneGame_->GetPlayerPos();
    //�v���C���[�̑������W�̊i�[�̈�
    Vector2 footPos = sceneGame_->GetPlayerPos();

    auto& ins = InputManager::GetInstance();

    //���ׂ�
    if (ins.IsNew(KEY_INPUT_F))
    {
        Stage::TYPE nowMapType = stage_->GetMapType();


        if (nowMapType == Stage::TYPE::RIVING
            && ((pos.x / Stage::CHIPS_SIZE_X == 16 && pos.y / Stage::CHIPS_SIZE_Y == 3)))
        {
            isWindow_ = true;
        }

        if (nowMapType == Stage::TYPE::JRM
            && ((pos.x / Stage::CHIPS_SIZE_X == 10 && pos.y / Stage::CHIPS_SIZE_Y == 4)))
        {
            isWindow_ = true;
        }
        
    }
}

void GimmickWindow::Draw(void)
{
    sPos_ = { (application::SCREEN_SIZE_X - WINDOW_SIZE_X) / 2 , (application::SCREEN_SIZE_Y - WINDOW_SIZE_Y) / 2 };
    ePos_ = { (application::SCREEN_SIZE_X + WINDOW_SIZE_X) / 2 , (application::SCREEN_SIZE_Y + WINDOW_SIZE_Y) / 2 };
    /*sPos_.x = (application::SCREEN_SIZE_X - WINDOW_SIZE_X) / 2;
    sPos_.y = (application::SCREEN_SIZE_Y - WINDOW_SIZE_Y) / 2;
    ePos_.x = (application::SCREEN_SIZE_X + WINDOW_SIZE_X) / 2;
    ePos_.y = (application::SCREEN_SIZE_Y + WINDOW_SIZE_Y) / 2;*/

    Stage::TYPE nowType = stage_->GetMapType();

    if (isWindow_)
    {
        SetFontSize(16);

        //����
        SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
        DrawBox(sPos_.x, sPos_.y, ePos_.x, ePos_.y, 0x000000, true);
        SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

        //�g
        DrawBox(sPos_.x, sPos_.y, ePos_.x, ePos_.y, 0xffffff, false);

        // ���̒������͎w��������̕`��
       // DrawString(sPos_.x+20, sPos_.y+20, "____", GetColor(255, 255, 255));

        int max = 99999;
        int num = KeyInputNumber(sPos_.x + 20, sPos_.y + 20, max, 0,true);
        if (nowType == Stage::TYPE::RIVING && num == 4210)
        {
            isWindow_ = false;
            item_->FroKeyState(Item::STATE::GET);
        }
        else if (nowType == Stage::TYPE::JRM && num == 78675)
        {
            isWindow_ = false;
            item_->ScissorsState(Item::STATE::GET);
        }
        else
        {
            isWindow_ = false;
        }
        
    }
}

bool GimmickWindow::Release(void)
{
    return true;
}

Vector2 GimmickWindow::World2MapPos(Vector2 worldPos)
{
    Vector2 mapPos;		//�߂�l�p�̕ϐ�

    mapPos.x = worldPos.x / Stage::CHIPS_SIZE_X;
    mapPos.y = worldPos.y / Stage::CHIPS_SIZE_Y;

    return mapPos;
}
