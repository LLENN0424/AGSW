#include "Vector2.h"
#include "SceneManager.h"
#include "InputManager.h"
#include "application.h"
#include "AsoUtility.h"
#include "SceneGame.h"
#include "stage.h"
#include "player.h"
#include "item.h"



Item::Item(Stage* stage)
{
    sceneManager_ = nullptr;
    state_ = STATE::NONE;
    froKey_ = STATE::NONE;
    rivKey_ = STATE::NONE;
    stick_ = STATE::NONE;
    paper_ = STATE::NONE;
    scissors_ = STATE::NONE;
    froKeyflg_ = false;
    rivKeyflg_ = false;
    stickflg_ = false;
    paperflg_ = false;
    scissorsflg_ = false;

    isHave_ = false;
    isBox_ = false;

    stage_ = stage;
}

Item::~Item()
{
}


bool Item::Init(SceneGame* parent, Stage* stage)
{
    //�C���X�^���X�̐����Ə�����
    stage_ = stage;
    sceneGame_ = parent;
    stImage_ = LoadGraph("bmp/bmp/stick.png");
    kImage_ = LoadGraph("bmp/bmp/roomkey.png");
    pImage_ = LoadGraph("bmp/bmp/paper.png");
    scisImage_ = LoadGraph("bmp/bmp/scissors.png");

    isHave_ = false;

    textPos_ = { 0,400 };

    isBox_ = false;

    return true;
}

void Item::Update(void)
{
    //�A�C�e���o�b�O

    //�}�b�v�̎���
    //�^�C���ԍ��擾
    //�v���C���[�̍��W���}�b�v���W�ɕς���


    Vector2 mapPos;
    mapPos = World2MapPos(sceneGame_->GetPlayerPos());
    Vector2 pos = sceneGame_->GetPlayerPos();
    //�v���C���[�̑������W�̊i�[�̈�
    Vector2 footPos = sceneGame_->GetPlayerPos();

    auto& ins = InputManager::GetInstance();

    Stage::TYPE nowMapType = stage_->GetMapType();

    switch (state_)
    {
    case Item::STATE::NONE:
        //�I����n�T�~���Ƃ�

        //�ʂ�����݂��烊�r���O�̌����Ƃ�
        if (ins.IsNew(KEY_INPUT_F) && nowMapType == Stage::TYPE::CRM
            && ((pos.x / Stage::CHIPS_SIZE_X == 3 && pos.y / Stage::CHIPS_SIZE_Y == 3))
            && scissors_ == Item::STATE::HAVE)
        {
            //�A�C�e�����o�b�N�ɂ��܂�
            isHave_ = true;
            //�A�C�e���̏�Ԃ�������
            rivKey_ = STATE::GET;
            scissors_ = STATE::USED;
            scissorsflg_ = false;
            SetState(Item::STATE::HAVE);
        }
        //�g�F����_���Ƃ�
        if (ins.IsNew(KEY_INPUT_F) && nowMapType == Stage::TYPE::RIVING
            && ((pos.x / Stage::CHIPS_SIZE_X == 6 && pos.y / Stage::CHIPS_SIZE_Y == 3)))
        {

            stick_ = STATE::GET;
            rivKeyflg_ = false;
            //�A�C�e���̏�Ԃ�HAVE�ɕς���
            SetState(Item::STATE::HAVE);

        }

        break;
    case Item::STATE::HAVE:

        //�_���g���Ď����Ƃ�
        if (ins.IsNew(KEY_INPUT_F) && nowMapType == Stage::TYPE::RIVING
            && ((pos.x / Stage::CHIPS_SIZE_X == 17 && pos.y / Stage::CHIPS_SIZE_Y == 7))
            && stick_ == STATE::HAVE)
        {
            //�A�C�e���̏�Ԃ�������
            stickflg_ = false;
            paper_ = STATE::GET;
            stick_ == STATE::USED;
        }

        //���������Č����Ƃ�
        if (ins.IsNew(KEY_INPUT_F) && nowMapType == Stage::TYPE::RIVING
            && ((pos.x / Stage::CHIPS_SIZE_X == 16 && pos.y / Stage::CHIPS_SIZE_Y == 3))
            && paper_ == STATE::HAVE)
        {
            paper_ = STATE::USED;
            paperflg_ = false;
        }

        //���ւ̌����g��
        if (ins.IsNew(KEY_INPUT_F) && nowMapType == Stage::TYPE::FRONT
            && ((pos.x / Stage::CHIPS_SIZE_X == 6 && pos.y / Stage::CHIPS_SIZE_Y == 11)
                || (pos.x / Stage::CHIPS_SIZE_X == 7 && pos.y / Stage::CHIPS_SIZE_Y == 11))
            && froKey_ == STATE::HAVE)
        {
            //�A�C�e�����g��
            //��Ԃ�USED�ɕς���
            //froKey_ = STATE::USED;
            froKeyflg_ = false;
            SetState(Item::STATE::USED);
        }
        break;
    case Item::STATE::USED:
        break;
    default:
        break;
    }
}


void Item::Draw(void)
{
    //UI�̕\��
    DrawUI();

    //�A�C�e���o�b�O
    if (InputManager::GetInstance().IsNew(KEY_INPUT_B))
    {
        isBox_ = true;
    }

    //�C���x���g�����J��
    if (isBox_ == true)
    {
        //����
        SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
        DrawBox(100, 100, 700, 500, 0x000000, true);
        SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

        //�g
        DrawBox(100, 100, 700, 500, 0xffffff, false);
        DrawFormatString(120, 120, 0xffffff, "�C���x���g��");
        DrawFormatString(500, 450, 0xffffff, "- V�ŕ��� -");
        if (scissorsflg_ == true)
        {
            DrawFormatString(120, 180, 0xffffff, "�n�T�~");
        }
        if (rivKeyflg_ == true)
        {
            DrawFormatString(120, 180, 0xffffff, "���r���O�̌�");
        }
        if (stickflg_ == true)
        {
            DrawFormatString(120, 180, 0xffffff, "�؂̖_");
        }
        if (paperflg_ == true)
        {
            DrawFormatString(120, 180, 0xffffff, "�Î�");
            DrawRotaGraph(application::SCREEN_SIZE_X / 2, application::SCREEN_SIZE_Y / 2,
                0.50f, 0.0f, pImage_, true);
        }
        if (froKeyflg_ == true)
        {
            DrawFormatString(120, 180, 0xffffff, "���ւ̌�");
        }
    }

    //�A�C�e���o�b�O�����
    if (InputManager::GetInstance().IsNew(KEY_INPUT_V))
    {
        isBox_ = false;
    }

}

bool Item::Release(void)
{
    //�摜�̉��
    DeleteGraph(scisImage_);
    DeleteGraph(stImage_);
    DeleteGraph(kImage_);
    DeleteGraph(pImage_);

    return false;
}

void Item::DrawUI(void)
{
    //���̃}�b�v���ǂꂩ
    Stage::TYPE nowType = stage_->GetMapType();
    Vector2 mapPos = World2MapPos(sceneGame_->GetPlayerPos());
    Vector2 pos = sceneGame_->GetPlayerPos();

    //�����T�C�Y�̐ݒ�
    SetFontSize(SceneGame::FONT_SIZE);


    bool textflg_ = true;
    int gCntMax = 50;

    //�n�T�~
    if (nowType == Stage::TYPE::CRM
        && ((pos.x / Stage::CHIPS_SIZE_X == 3 && pos.y / Stage::CHIPS_SIZE_Y == 3)))
    {
        if (scissors_ != STATE::USED)
        {
            //�e�L�X�g�{�b�N�X�\��
            DrawTextBox();
            DrawFormatString(textPos_.x, textPos_.y, 0xffffff, "�ʂ�����݂̒��ɂȂɂ�����B");
        }
    }
    if (scissors_ == STATE::GET)
    {
        gCount_++;
        DrawTextBox();
        DrawRotaGraph(application::SCREEN_SIZE_X / 2, application::SCREEN_SIZE_Y / 2,
            0.50f, 0.0f, scisImage_, true);
        DrawString(textPos_.x, textPos_.y, "�n�T�~����ɓ��ꂽ", 0xffffff);

        if (gCount_ == gCntMax)
        {

            scissors_ = STATE::HAVE;
            scissorsflg_ = true;
            gCount_ = 0;
        }
    }
    //���r���O�̌�
    if (rivKey_ == STATE::GET)
    {
        gCount_++;
        DrawTextBox();
        DrawRotaGraph(application::SCREEN_SIZE_X / 2, application::SCREEN_SIZE_Y / 2,
            2.0f, 0.0f, kImage_, true);
        DrawString(textPos_.x, textPos_.y, "���r���O�̌�����ɓ��ꂽ", 0xffffff);

        if (gCount_ == gCntMax)
        {

            rivKey_ = STATE::HAVE;
            state_ = STATE::NONE;
            rivKeyflg_ = true;
            gCount_ = 0;
        }
    }


    if (nowType == Stage::TYPE::RIVING
        && ((pos.x / Stage::CHIPS_SIZE_X == 17 && pos.y / Stage::CHIPS_SIZE_Y == 7)))
    {
        if (stick_ == STATE::NONE)
        {
            //�e�L�X�g�{�b�N�X�\��
            DrawTextBox();
            DrawFormatString(textPos_.x, textPos_.y, 0xffffff, "�\�t�@�̉��ɉ�������B�������̂��g���΂Ƃꂻ����");
        }
        //�Î�
        if (paper_ == STATE::GET)
        {
            gCount_++;
            //�e�L�X�g�{�b�N�X�\��
            DrawTextBox();
            DrawRotaGraph(application::SCREEN_SIZE_X / 2, application::SCREEN_SIZE_Y / 2,
                0.50f, 0.0f, pImage_, true);
            DrawString(textPos_.x, textPos_.y, "�Î�����ɓ��ꂽ", 0xffffff);

            if (gCount_ == gCntMax)
            {
                paper_ = STATE::HAVE;
                stick_ = STATE::USED;
                paperflg_ = true;
                gCount_ = 0;
            }
        }
        
    }

    //���ւ̌�
    if (froKey_ == STATE::GET)
    {
        gCount_++;
        DrawTextBox();
        DrawRotaGraph(application::SCREEN_SIZE_X / 2, application::SCREEN_SIZE_Y / 2,
            2.0f, 0.0f, kImage_, true);
        DrawString(textPos_.x, textPos_.y, "���ւ̌�����ɓ��ꂽ", 0xffffff);

        if (gCount_ == gCntMax)
        {
            froKey_ = STATE::HAVE;
            state_ = STATE::USED;
            froKeyflg_ = true;
            gCount_ = 0;
        }
    }

    //�؂̖_
    if (stick_ == STATE::GET)
    {
        gCount_++;
        DrawTextBox();
        DrawRotaGraph(application::SCREEN_SIZE_X / 2, application::SCREEN_SIZE_Y / 2,
            3.0f, 0.0f, stImage_, true);
        DrawString(textPos_.x, textPos_.y, "�؂̖_����ɓ��ꂽ", 0xffffff);

        if (gCount_ == gCntMax)
        {
            stick_ = STATE::HAVE;
            stickflg_ = true;
            gCount_ = 0;
        }
    }

    if (nowType == Stage::TYPE::CRM
        && ((pos.x / Stage::CHIPS_SIZE_X == 7 && pos.y / Stage::CHIPS_SIZE_Y == 3)))
    {
        //�e�L�X�g�{�b�N�X�\��
        DrawTextBox();

        DrawFormatString(textPos_.x, textPos_.y, 0xffffff, "���v��12��21���Ŏ~�܂��Ă���");
    }
}

void Item::DrawTextBox(void)
{
    //�e�L�X�g�{�b�N�X�̈ʒu
    Vector2 StrPos = { 0,400 };	//�n�_
    Vector2 EndPos = { 600,500 };	//�I�_

    //�e�L�X�g�{�b�N�X
    SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
    DrawBox(StrPos.x, StrPos.y, EndPos.x, EndPos.y, 0x000000, true);
    SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);

    //�g
    DrawBox(StrPos.x, StrPos.y, EndPos.x, EndPos.y, 0xfffffff, false);
}

void Item::SetState(STATE state)
{
    state_ = state;
}

Item::STATE Item::GetState(void)
{
    return state_;
}

void Item::SetPaperState(STATE paper)
{
    paper_ = paper;
}

Item::STATE Item::GetPaperState(void)
{
    return paper_;
}

bool Item::IsHave(void)
{
    return isHave_;
}

Item::STATE Item::FroKeyState(STATE state)
{
    return froKey_ = state;
}

Item::STATE Item::ScissorsState(STATE state)
{
    return scissors_ = state;
}

Vector2 Item::World2MapPos(Vector2 worldPos)
{
    Vector2 mapPos;        //�߂�l�p�̕ϐ�

    mapPos.x = worldPos.x / Stage::CHIPS_SIZE_X;
    mapPos.y = worldPos.y / Stage::CHIPS_SIZE_Y;

    return mapPos;
}


Vector2 Item::GetPlayerPos(void)
{
    return sceneGame_->GetPlayerPos();
}