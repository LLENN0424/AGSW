<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="全体" tilewidth="32" tileheight="32" tilecount="3600" columns="60">
 <image source="../../Map/全体.png" width="1920" height="1920"/>
</tileset>
